﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OracleClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;


namespace rosterForm
{
    public class BL
    {
        public OracleConnection con = new OracleConnection(ConfigurationManager.ConnectionStrings["conn"].ToString());
        OracleDataAdapter da = null;
        DataSet ds = new DataSet();
        OracleDataReader dr = null;
        DataTable dt = new DataTable();
        public OracleCommand cmd = null;
        OracleTransaction trans = null;
        public static string ConnectionString = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;

        public string GetConnectionString()
        {
            string conStr = ConfigurationManager.ConnectionStrings["conn"].ConnectionString.ToString().Trim();

            return conStr;
        }

        public void OpenConn()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }

        public void CloseConn()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

        public int GetNextId(string tableName, string columnName)
        {
            OpenConn();

            string str = "SELECT NVL(MAX(" + columnName + "),0)+1 FROM " + tableName + "";
            cmd = new OracleCommand(str, con);
            int result = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            return result;

        }

        public int ExecuteNQuery(string str)
        {
            try
            {
                OpenConn();
                cmd = new OracleCommand(str, con);
                int i = cmd.ExecuteNonQuery();
                CloseConn();
                return i;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int ExecuteNonQry(string qry)
        {
            int result = 0;
            try
            {
                OpenConn();
                //trans = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted);
                cmd = new OracleCommand(qry, con);
                //cmd.Transaction = trans;
                result = cmd.ExecuteNonQuery();
                //trans.Commit();
                con.Close();
                // return i;
            }
            catch (Exception ex)
            {

            }
            return result;
        }

        public OracleDataReader getIntoDataReader(string str)
        {
            OpenConn();
            using (cmd = new OracleCommand(str, con))
            {
                dr = cmd.ExecuteReader();

                return dr;
            }
        }

        public DataTable ExecuteQry(string qry)
        {
            OracleDataReader result = null;
            DataTable dt = new DataTable();
            try
            {
                OpenConn();
                //trans = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted);
                cmd = new OracleCommand(qry, con);
                //cmd.Transaction = trans;
                result = cmd.ExecuteReader();
                dt.Load(result);
                //trans.Commit();
                con.Close();
                // return i;
            }
            catch (Exception ex)
            {

            }

            return dt;
        }

        public int ExecuteQry_Count(string qry)
        {
            OracleDataReader result = null;
            DataTable dt = new DataTable();
            try
            {
                OpenConn();
                //trans = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted);
                cmd = new OracleCommand(qry, con);
                //cmd.Transaction = trans;
                result = cmd.ExecuteReader();
                dt.Load(result);
                //trans.Commit();
                con.Close();
                // return i;
            }
            catch (Exception ex)
            {

            }

            return dt.Rows.Count;
        }

        #region Send email
        public static bool Email_Send(string from, string empidto, string cc, string bcc, string msg, string subject, string attachment, out string errorMsg)
        {
            errorMsg = "";
            bool sent = false;
            string body;
            MailMessage mailObj = new MailMessage();
            SmtpClient SMTPServer = new SmtpClient();
            SMTPServer.EnableSsl = false;
            SMTPServer.Credentials = CredentialCache.DefaultNetworkCredentials;
            SMTPServer.UseDefaultCredentials = false;
            mailObj.From = new MailAddress(from);
            //empidto = "system@gail.co.in";
            if (!string.IsNullOrEmpty(empidto))
            {
                string[] multiTo = (empidto).Split(',');
                foreach (string emailID in multiTo)
                { mailObj.To.Add(emailID); }
            }
            if (!string.IsNullOrEmpty(cc))
            {
                string[] multiCC = (cc).Split(',');
                foreach (string emailIDCC in multiCC)
                { mailObj.CC.Add(emailIDCC); }
            }
            //mailObj.Bcc.Add(bcc);
            mailObj.Subject = subject;
            // mailObj.Bcc.Add("system@gail.co.in");
            try
            {
                if (!string.IsNullOrEmpty(attachment))
                    mailObj.Attachments.Add(new Attachment(attachment));
            }
            catch (Exception)
            {
                throw;
            }

            body = " <html>" +
            " <head>" +
            " </head>" +
            " <body>" +
            " <table>" +
            " <tr>" +
            " <td>" +
            " </td>" +
            " </tr><tr><td></td></tr>" +
            " <tr>" +
            " <td colspan='2'> " + msg + "</td>" +
            " </tr>" +
            " <tr><td> <B></B> </td>" +
            " </tr>" +
            " <tr height='50px'><td></td>" +
            " </tr>" +
            " <tr><td>Regards,</td>" +
            " </tr>" +
            " <tr><td>GAIL Recruitment Team</td>" +
            " </tr>" +
            " <tr><td></td>" +
            " </tr>" +
            " <td align=left>This is a system generated email. Please don't reply to this email..</td></tr> " +
            " <tr><td align=left>**********************************************************************************************************************</td></tr>" +
            " </table>" +
            " </body>" +
            " </html>";

            mailObj.Body = body;
            mailObj.IsBodyHtml = true;

            try
            {
                ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                SMTPServer.Send(mailObj);
                sent = true;
            }
            catch (Exception ex)
            {
                errorMsg = ex.Message;
                while ((ex = ex.InnerException) != null)
                {
                    errorMsg += " | " + ex.Message;
                }
                //System.Windows.Forms.MessageBox.Show(msgEx);
                sent = false;
            }
            mailObj.Dispose();
            return sent;
        }
        #endregion


        public void SendMsg(string mobileNo, string msg)
        {
            try
            {
                BL bl = new BL();
                string url = "https://gail.dove-sms.com/submitsms.jsp?user=gailintr&key=7ee125ea3cXX&mobile=" + mobileNo + @"&message=" + msg + @"&senderid=GAILIN&accusage=1&iscampaign=1";
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(url);
                ASCIIEncoding encoding = new ASCIIEncoding();
                string postData = "";
                byte[] data = encoding.GetBytes(postData);
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = data.Length;
                httpWReq.Proxy = WebRequest.DefaultWebProxy;
                //   httpWReq.Proxy.Credentials = new NetworkCredential("mansi", "Alphabet@34", "gail");
                // WebRequest.DefaultWebProxy.Credentials = new NetworkCredential("mansi", "Alphabet@34", "gail");
                string qrt = @"select * from CGD_API_CREDENTIALS where PLATFORM='SMS'";
                DataTable dt = bl.ExecuteQry(qrt);
                httpWReq.Proxy.Credentials = new NetworkCredential(dt.Rows[0]["USERNAME"].ToString(), Decrypt(dt.Rows[0]["PASSWORD"].ToString()), dt.Rows[0]["DOMAIN"].ToString());
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                //Get Response
                string responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                System.Diagnostics.Debug.Print(responseString);
                ////JSON///////////////
                JavaScriptSerializer jsSerializer = new JavaScriptSerializer();
                var result = jsSerializer.DeserializeObject(responseString);
                Dictionary<string, object> obj2 = new Dictionary<string, object>();
                obj2 = (Dictionary<string, object>)(result);
                string Status = obj2["result"].ToString();
            }
            catch (Exception ex)
            {
                // clsExceptionLog.WriteToErrorLog(ex.Message + " userlogin.aspx : ", ex.StackTrace, "Error");
                // json = JsonConvert.SerializeObject(routData, Formatting.Indented);
            }
        }

        public string Decrypt(string cipherText)
        {
            try
            {
                if (cipherText == null)
                {
                    cipherText = "";
                }
                string EncryptionKey = "G@il";
                cipherText = cipherText.Replace(" ", "+");
                //cipherText = HttpContext.Current.Server.UrlDecode(cipherText);
                byte[] cipherBytes = Convert.FromBase64String(cipherText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        cipherText = Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
            }
            catch (Exception ex)
            {
                //ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is " + ex.Message.Replace("'", "") + "');", true);
            }
            return cipherText;

        }


        #region [Default Function By Vikas Mehra Bisht]

        private void ConnectionOpen()
        {
            con = new OracleConnection(ConnectionString);
            con.Open();
        }

        private void ConnectionClosed()
        {
            if (con != null)
            {
                con.Close();
            }
        }

        public int ExecuteQuery(string Query)
        {
            int RetrunID;
            ConnectionOpen();
            cmd = new OracleCommand(Query, con);
            RetrunID = cmd.ExecuteNonQuery();
            ConnectionClosed();
            return RetrunID;
        }

        public int ExecuteIntScalar(string Query)
        {
            int RetrunStr;
            ConnectionOpen();
            cmd = new OracleCommand(Query, con);
            RetrunStr = Convert.ToInt32(cmd.ExecuteScalar());
            ConnectionClosed();
            return RetrunStr;
        }

        public string ExecuteStringScalar(string Query)
        {
            string RetrunStr;
            ConnectionOpen();
            cmd = new OracleCommand(Query, con);
            RetrunStr = Convert.ToString(cmd.ExecuteScalar());
            ConnectionClosed();
            return RetrunStr;
        }

        public DataTable GetDatatable(string Query)
        {
            ConnectionOpen();
            cmd = new OracleCommand(Query, con);
            da = new OracleDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ConnectionClosed();
            return ds.Tables[0];
        }

        public DataSet GetDataSet(string Query)
        {
            ConnectionOpen();
            cmd = new OracleCommand(Query, con);
            da = new OracleDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ConnectionClosed();
            return ds;
        }

        #endregion


    }
}