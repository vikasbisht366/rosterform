﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Data.OracleClient;
using System.IO;
using System.Configuration;
using System.Text.RegularExpressions;

namespace rosterForm
{
    public partial class postMaster : System.Web.UI.Page
    {
        public BL bl = new BL();

        #region [Page_Load]
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    bind_ddl();
                    bindGrid();

                    if (Request.QueryString["id"] != null)
                    {
                        string posId = Request.QueryString["id"].ToString();
                        updateDetails(posId);
                        Submit.Visible = false;
                        Update.Visible = true;
                        GRDEDITCategory.Visible = true;
                        GRDCategory.Visible = false;
                    }
                    else
                    {
                        BindCategory();
                        Submit.Visible = true;
                        Update.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                string strexception = ex.Message.Replace("'", "");
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is " + strexception + "');location.replace('https://mygail.gail.co.in/');", true);
            }
        }
        #endregion

        #region [Bind Data]

        private void BindCategory()
        {
            try
            {
                DataTable dt = bl.GetDatatable("select * from ROSTER_CATEGORY_MASTER where isactive='1'");
                if (dt.Rows.Count > 0)
                {
                    GRDCategory.DataSource = dt;
                    GRDCategory.DataBind();
                }
            }
            catch
            {
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is please try after sometime !');location.replace('https://mygail.gail.co.in/');", true);
            }
        }

        protected void bindGrid()
        {
            try
            {
                string qry = @"select ID,POST_NAME,GROUP_RST,MOD_OF_REQ from ROSTER_POST_MASTER order by ID asc";
                DataTable dt = bl.ExecuteQry(qry);
                if (dt.Rows.Count > 0)
                {
                    grdPosition.DataSource = dt;
                    grdPosition.DataBind();
                }
            }
            catch (Exception ex)
            {
                string strexception = ex.Message.Replace("'", "");
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is " + strexception + "');location.replace('https://mygail.gail.co.in/');", true);
            }

        }

        protected void updateDetails(string posID)
        {
            try
            {
                string qry = @"select * from ROSTER_POST_MASTER where ID=" + posID;
                DataTable dt = bl.ExecuteQry(qry);
                if (dt.Rows.Count > 0)
                {
                    txtPost.Text = dt.Rows[0]["POST_NAME"] + "";
                    ddlGroup.SelectedValue = dt.Rows[0]["GROUP_RST"] + "";
                    ddlRecruit.SelectedValue = dt.Rows[0]["MOD_OF_REQ"] + "";

                    qry = @"select * from ROSTER_POST_GRADE_MAPPING where POST_ID=" + posID;
                    dt = bl.ExecuteQry(qry);
                    if (dt.Rows.Count > 0)
                    {
                        string valGrd = @"";
                        foreach (DataRow dr in dt.Rows)
                        {
                            valGrd += dr["GRADE_ID"] + ",";
                        }
                        ddlGrade.SelectionMode = ListSelectionMode.Multiple;
                        foreach (ListItem item in ddlGrade.Items)
                        {
                            if (valGrd.Contains(item.Text))
                            {
                                item.Selected = true;
                            }
                        }
                    }

                    qry = @"select * from ROSTER_POST_DISCIPLINE_MAPPING where POST_ID=" + posID;
                    dt = bl.ExecuteQry(qry);
                    if (dt.Rows.Count > 0)
                    {
                        string valGrd = @"";
                        ddlDiscipline.SelectionMode = ListSelectionMode.Multiple;

                        foreach (DataRow dr in dt.Rows)
                        {
                            valGrd += dr["DISCIPLINE_ID"] + ",";
                            foreach (ListItem item in ddlDiscipline.Items)
                            {
                                if (dr["DISCIPLINE_ID"].Equals(item.Text))
                                {
                                    item.Selected = true;
                                }
                            }

                        }
                    }

                    DataTable dtbindcategory = bl.GetDatatable("select * from ROSTER_POST_CATEGORY_MAPPING where PMID='" + posID + "'");
                    if (dtbindcategory.Rows.Count > 0)
                    {
                        GRDEDITCategory.DataSource = dtbindcategory;
                        GRDEDITCategory.DataBind();
                    }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('Invalid Request ID !');location.replace('PostMaster.aspx');", true);
                }
            }
            catch (Exception ex)
            {
                string strexception = ex.Message.Replace("'", "");
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is " + strexception + "');location.replace('https://mygail.gail.co.in/');", true);
            }
        }

        protected void bind_ddl()
        {
            try
            {
                BL bl = new BL();
                string qry = @"select distinct(Upper(JOINING_DISCIPLINE)) as JOINING_DISCIPLINE from gailinter.ROSTER_CADRE_MASTER 
                where JOINING_DISCIPLINE != ' ' order by JOINING_DISCIPLINE ASC";
                DataTable dt = bl.ExecuteQry(qry);

                if (dt.Rows.Count > 0)
                {
                    ddlDiscipline.DataSource = dt;
                    ddlDiscipline.DataTextField = "JOINING_DISCIPLINE";
                    ddlDiscipline.DataValueField = "JOINING_DISCIPLINE";
                    ddlDiscipline.DataBind();
                    //   ddlDiscipline.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Please select", "0"));
                }
                else
                {
                    ddlDiscipline.Items.Clear();
                    ddlDiscipline.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Please select", "0"));
                }


                qry = @"select distinct(GRADE_NAME) as GRADE_NAME from gailinter.ROSTER_GRADE_MASTER";
                dt = bl.ExecuteQry(qry);

                if (dt.Rows.Count > 0)
                {
                    ddlGrade.DataSource = dt;
                    ddlGrade.DataTextField = "GRADE_NAME";
                    ddlGrade.DataValueField = "GRADE_NAME";
                    ddlGrade.DataBind();
                    // ddlGrade.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Please select", "0"));
                }
                else
                {
                    ddlGrade.Items.Clear();
                    ddlGrade.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Please select", "0"));
                }

            }
            catch (Exception ex)
            {
                string strexception = ex.Message.Replace("'", "");
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is " + strexception + "');location.replace('https://mygail.gail.co.in/');", true);
            }
        }

        #endregion

        #region [Submit And Update]
        protected void Submit_Click(object sender, EventArgs e)
        {
            try
            {
                string gradeList = @"";
                string discList = @"";
                foreach (ListItem listItem in ddlGrade.Items)
                {
                    if (listItem.Selected)
                    {
                        gradeList += listItem.Value.Trim() + ",";
                    }
                }
                foreach (ListItem listItem in ddlDiscipline.Items)
                {
                    if (listItem.Selected)
                    {
                        discList += listItem.Value.Trim() + ",";
                    }
                }

                if (gradeList.Length == 0)
                {
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "clentscript", "alert('Please select grade');", true);
                    return;
                }
                if (discList.Length == 0)
                {
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "clentscript", "alert('Please select discipline');", true);
                    return;
                }
                if (txtPost.Text.Equals(""))
                {
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "clentscript", "alert('Please enter post name');", true);
                    return;
                }

                int id = bl.GetNextId("ROSTER_POST_MASTER", "ID");
                int gid = 0;
                int did = 0;
                string qry = @"";
                if (Request.QueryString["id"] != null)
                {
                    id = Convert.ToInt32(Request.QueryString["id"].ToString());
                    qry = @"delete from ROSTER_POST_MASTER where ID=" + id;
                    bl.ExecuteQuery(qry);
                    qry = @"delete from ROSTER_POST_GRADE_MAPPING where POST_ID=" + id;
                    bl.ExecuteQuery(qry);
                    qry = @"delete from ROSTER_POST_DISCIPLINE_MAPPING where POST_ID=" + id;
                    bl.ExecuteQuery(qry);
                    qry = @"delete from ROSTER_POST_CATEGORY_MAPPING where PMID=" + id;
                    bl.ExecuteQuery(qry);
                }

                qry = @"select * from ROSTER_POST_MASTER where POST_NAME='" + txtPost.Text.ToUpper().Trim() + @"'";
                DataTable dt = bl.GetDatatable(qry);
                if (dt.Rows.Count > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "clentscript", "alert('This post name is already defined');", true);
                    return;
                }
                else
                {
                    qry = @"insert into ROSTER_POST_MASTER(ID,POST_NAME,GROUP_RST,MOD_OF_REQ) values(" + id + ",'" + txtPost.Text.ToUpper().Trim() + @"','" + ddlGroup.SelectedValue + @"','" + ddlRecruit.SelectedValue + @"')";
                    int flag = bl.ExecuteQuery(qry);
                    if (flag != 0)
                    {
                        foreach (ListItem listItem in ddlGrade.Items)
                        {
                            if (listItem.Selected)
                            {
                                gid = bl.GetNextId("ROSTER_POST_GRADE_MAPPING", "ID");
                                qry = @"insert into ROSTER_POST_GRADE_MAPPING(ID,POST_ID,GRADE_ID) values (" + gid + "," + id + @",
                            '" + listItem.Value.ToString() + @"')";
                                bl.ExecuteQuery(qry);
                            }
                        }
                        foreach (ListItem listItem in ddlDiscipline.Items)
                        {
                            if (listItem.Selected)
                            {
                                did = bl.GetNextId("ROSTER_POST_DISCIPLINE_MAPPING", "ID");
                                qry = @"insert into ROSTER_POST_DISCIPLINE_MAPPING(ID,POST_ID,DISCIPLINE_ID) values (" + gid + "," + id + @",
                            '" + listItem.Value.ToString() + @"')";
                                bl.ExecuteQuery(qry);
                            }
                        }

                        if (Request.QueryString["id"] != null)
                        {
                            foreach (GridViewRow grd in GRDEDITCategory.Rows)
                            {
                                TextBox txtPercentage = (TextBox)grd.FindControl("txtEDITPercentage");
                                HiddenField hidcategoryid = (HiddenField)grd.FindControl("hidEDITcategoryid");
                                Label lblcategoryname = (Label)grd.FindControl("lblEDITcategoryname");

                                qry = @"insert into ROSTER_POST_CATEGORY_MAPPING(CID,CategoryName,PMID,Percentage) values ('" + Convert.ToInt32(hidcategoryid.Value) + "','" + lblcategoryname.Text.Trim() + "','" + id + "','" + Convert.ToDecimal(txtPercentage.Text.Trim()) + "')";
                                bl.ExecuteQuery(qry);
                            }
                        }
                        else
                        {
                            foreach (GridViewRow grd in GRDCategory.Rows)
                            {
                                TextBox txtPercentage = (TextBox)grd.FindControl("txtPercentage");
                                HiddenField hidcategoryid = (HiddenField)grd.FindControl("hidcategoryid");
                                Label lblcategoryname = (Label)grd.FindControl("lblcategoryname");

                                qry = @"insert into ROSTER_POST_CATEGORY_MAPPING(CID,CategoryName,PMID,Percentage) values ('" + Convert.ToInt32(hidcategoryid.Value) + "','" + lblcategoryname.Text.Trim() + "','" + id + "','" + Convert.ToDecimal(txtPercentage.Text.Trim()) + "')";
                                bl.ExecuteQuery(qry);
                            }
                        }
                        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "clentscript", "alert('Data is successfully updated');location.replace('postMaster.aspx');", true);
                    }
                }
            }
            catch (Exception ex)
            {
                string strexception = ex.Message.Replace("'", "");
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is " + strexception + " ');location.replace('https://mygail.gail.co.in/');", true);
            }
        }
        #endregion

        #region [GRID VIEW Events]
        protected void grdPosition_RowCommand(object sender, GridViewCommandEventArgs e)
        {


            try
            {
                BL bl = new BL();

                if (e.CommandName == "editRow")
                {
                    string P_ID = e.CommandArgument.ToString();
                    string url = @"postMaster.aspx?id=" + P_ID.ToString();
                    Response.Redirect(url);
                }

                if (e.CommandName == "HrActivity")
                {
                    string P_ID = e.CommandArgument.ToString();
                    string[] values = P_ID.Split('_');
                    string final = "";

                    GridViewRow gvr = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                    int RemoveAt = gvr.RowIndex;
                    Label lblVerifiedBy = ((Label)grdPosition.Rows[RemoveAt].FindControl("lblVerifier"));
                    lblPostName.Text = lblVerifiedBy.Text;

                    string qry = @"select distinct(GRADE_ID),ID from ROSTER_POST_GRADE_MAPPING where POST_ID=" + P_ID + @" order by ID";
                    DataTable dt = bl.ExecuteQry(qry);
                    string lblGrad = @"";
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lblGrad += dr["GRADE_ID"] + ",";
                        }
                        lblCategories.Text = lblGrad.Substring(0, lblGrad.Length - 1);
                    }

                    qry = @"select distinct(DISCIPLINE_ID),ID from ROSTER_POST_DISCIPLINE_MAPPING where POST_ID=" + P_ID + @" order by ID";
                    dt = bl.ExecuteQry(qry);
                    string lblDiscp = @"";
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lblDiscp += dr["DISCIPLINE_ID"] + ",";
                        }
                        lblDiscipline.Text = lblDiscp.Substring(0, lblDiscp.Length - 1);
                    }

                    DataTable dtsubmited = bl.GetDatatable("select * from ROSTER_POST_CATEGORY_MAPPING where PMID='" + P_ID + "'");
                    if (dtsubmited.Rows.Count > 0)
                    {
                        GRDPOSTCATEGORYPERCENT.DataSource = dtsubmited;
                        GRDPOSTCATEGORYPERCENT.DataBind();
                    }

                    mpePopUp.Show();
                }
            }
            catch (Exception ex)
            {

            }
        }

        protected void grdPosition_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }
        #endregion



    }
}