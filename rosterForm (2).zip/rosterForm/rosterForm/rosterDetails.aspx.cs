﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Data.OracleClient;
using System.IO;
using System.Configuration;
using System.Text.RegularExpressions;

namespace rosterForm
{
    public partial class rosterDetails : System.Web.UI.Page
    {
        public BL bl = new BL();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    bind_ddl();
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is " + ex.Message.Replace("'", "") + "');window.location ='https://mygail.gail.co.in/';", true);
            }

        }

        protected void bind_ddl()
        {
            try
            {
                BL bl = new BL();
                string qry = @"select distinct(POST_NAME) as POST_NAME,ID from gailinter.ROSTER_POST_MASTER order by ID ASC";
                DataTable dt = bl.ExecuteQry(qry);
                if (dt.Rows.Count > 0)
                {
                    ddlPost.DataSource = dt;
                    ddlPost.DataTextField = "POST_NAME";
                    ddlPost.DataValueField = "ID";
                    ddlPost.DataBind();
                }
                else
                {
                    ddlPost.Items.Clear();
                    ddlPost.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Please select", "0"));
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is " + ex.Message.Replace("'", "") + "');window.location ='https://mygail.gail.co.in/';", true);
            }
        }

        protected void ddlPost_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                bindGrid();
            }
            catch (Exception ex)
            {
                string strerrormsg = ex.Message.Replace("'", "");
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is " + strerrormsg + "');location.replace('https://mygail.gail.co.in/');", true);
            }
        }
        protected void txtFinancialYear_TextChanged(object sender, EventArgs e)
        {
            try
            {
                bindGrid();
            }
            catch (Exception ex)
            {
                string strerrormsg = ex.Message.Replace("'", "");
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is " + strerrormsg + "');location.replace('https://mygail.gail.co.in/');", true);
            }
        }

        protected void bindGrid()
        {
            try
            {
                string qry = @"";
                string recruitMode = @"";
                string discipline = @"";
                string grade = @"";
                DataTable dt = null;
                if (!ddlPost.SelectedValue.ToString().Equals(""))
                {
                    lblPost.Text = ddlPost.SelectedItem.Text.Trim().ToUpper();
                    qry = @"select MOD_OF_REQ from ROSTER_POST_MASTER where id=" + ddlPost.SelectedValue;
                    dt = bl.ExecuteQry(qry);
                    if (dt.Rows.Count > 0)
                    {
                        recruitMode = dt.Rows[0]["MOD_OF_REQ"] + "";
                    }
                    lblRecruitmode.Text = recruitMode.Trim().ToUpper();
                    dt.Clear();
                    qry = @"select distinct(GRADE_ID),ID from ROSTER_POST_GRADE_MAPPING where POST_ID=" + ddlPost.SelectedValue + @" order by ID";
                    dt = bl.ExecuteQry(qry);
                    string lblGrad = @"";
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lblGrad += "'" + dr["GRADE_ID"] + "',";
                        }
                        grade = lblGrad.Substring(0, lblGrad.Length - 1);
                    }
                    qry = @"select distinct(DISCIPLINE_ID),ID from ROSTER_POST_DISCIPLINE_MAPPING where POST_ID=" + ddlPost.SelectedValue + @" order by ID";
                    dt = bl.ExecuteQry(qry);
                    string lblDiscp = @"";
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lblDiscp += "'" + dr["DISCIPLINE_ID"] + "',";
                        }
                        discipline = lblDiscp.Substring(0, lblDiscp.Length - 1);
                    }
                }

                qry = @"select EMP_NO,EMP_NAME,RECRUITMENT_MODE,WITH_TEST,JOINING_GRADE,JOINING_CATEGORY,JOINING_CATEGORY_QUOTA,
                JOINING_POSITION,to_char(JOINING_DATE,'dd/mm/yyyy')JOINING_DATE,JOINING_DATE as JD,JOINING_DISCIPLINE,ACTION_FLAG,DATE_OF_SEPERATION,
                to_char(JOINING_DATE,'YYYY')JOINING_YEAR  from ROSTER_CADRE_MASTER where JOINING_DISCIPLINE in (" + discipline + ") and JOINING_GRADE in (" + grade + ") ";
                if (ddlRosterType.SelectedValue.ToString().Equals("F"))
                {
                    qry += @" and DATE_OF_SEPERATION is null  ";
                }
                if (!recruitMode.Equals(""))
                {
                    qry += @" and RECRUITMENT_MODE ='" + recruitMode + "' ";
                }
                if (txtFinancialYear.Text != "")
                {
                    qry += @" and TRUNC(JOINING_DATE) <= TO_DATE('" + Convert.ToDateTime(txtFinancialYear.Text).ToString("dd-MM-yyyy") + "','dd/MM/yyyy') ";
                }
                qry += @" order by JD asc";
                dt = bl.ExecuteQry(qry);
                lblPostcount.Text = dt.Rows.Count + " (Based on actual data of cadre in SAP)";
                if (dt.Rows.Count > 0)
                {

                    #region [RESERVATION ROSTER REGISTER Point 4 start]
                    string CategoryQuery = "select a.PERCENTAGE,b.CATEGORYCODE from ROSTER_POST_CATEGORY_MAPPING a,ROSTER_CATEGORY_MASTER b where a.CID=b.cid and a.PMID='" + ddlPost.SelectedValue + "'";
                    DataTable dtCategorypercent = bl.ExecuteQry(CategoryQuery);
                    if (dtCategorypercent.Rows.Count > 0)
                    {
                        int OBC = 0, SC = 0, ST = 0;
                        for (int count = 0; count < dtCategorypercent.Rows.Count; count++)
                        {
                            if (dtCategorypercent.Rows[count]["CATEGORYCODE"].ToString().Trim() == "OBC")
                            {
                                OBC = Convert.ToInt32(dtCategorypercent.Rows[count]["PERCENTAGE"]);
                                ViewState["OBC"] = OBC;
                            }
                            if (dtCategorypercent.Rows[count]["CATEGORYCODE"].ToString().Trim() == "SC")
                            {
                                SC = Convert.ToInt32(dtCategorypercent.Rows[count]["PERCENTAGE"]);
                                ViewState["SC"] = SC;
                            }
                            if (dtCategorypercent.Rows[count]["CATEGORYCODE"].ToString().Trim() == "ST")
                            {
                                ST = Convert.ToInt32(dtCategorypercent.Rows[count]["PERCENTAGE"]);
                                ViewState["ST"] = ST;
                            }
                        }
                        ViewState["UR"] = (100 - (OBC + SC + ST));

                        lblPercentage.Text = " SCs - " + SC + "%, STs - " + ST + "%, OBCs - " + OBC + "%";
                        lblhindipercent.Text = "अजा - " + SC + "%, अजजा - " + ST + "%, ओबीसी - " + OBC + "%";
                    }
                    #endregion

                    hidtotalcount.Value = dt.Rows.Count.ToString();
                    //Percentage of Reservation prescription
                    string Query = "select count(emp_no) total,JOINING_CATEGORY_QUOTA from(" + qry + ") group by JOINING_CATEGORY_QUOTA";
                    DataTable dtcountcheck = bl.ExecuteQry(Query);
                    if (dtcountcheck.Rows.Count > 0)
                    {
                        grdcategorydescription.DataSource = dtcountcheck;
                        grdcategorydescription.DataBind();

                        decimal total = dtcountcheck.AsEnumerable().Sum(row => row.Field<decimal>("total"));
                        grdcategorydescription.FooterRow.Cells[1].Text = (Convert.ToInt32(ViewState["lbl_UR_REQUIRED"]) + Convert.ToInt32(ViewState["lbl_OBC_REQUIRED"]) + Convert.ToInt32(ViewState["lbl_SC_REQUIRED"]) + Convert.ToInt32(ViewState["lbl_ST_REQUIRED"])).ToString("#0");
                        grdcategorydescription.FooterRow.Cells[2].Text = total.ToString("#0");
                        grdcategorydescription.FooterRow.Cells[3].Text = (Convert.ToInt32(ViewState["lbl_UR_EXCESS"]) + Convert.ToInt32(ViewState["lbl_OBC_EXCESS"]) + Convert.ToInt32(ViewState["lbl_SC_EXCESS"]) + Convert.ToInt32(ViewState["lbl_ST_EXCESS"])).ToString("#0");
                    }

                    DataTable dtTemp = dt.Copy();
                    int rowYear = 0;
                    int lastYear = 0;
                    int i = 0;
                    foreach (DataRow dr in dtTemp.Rows)
                    {
                        rowYear = Convert.ToInt32(dr["JOINING_YEAR"].ToString());
                        if (rowYear > lastYear + 1)
                        {
                            if (lastYear != 0)
                            {
                                if (rowYear > lastYear)
                                {
                                    for (int incr = (lastYear + 1); incr < rowYear; incr++)
                                    {
                                        DataRow drNew = dt.NewRow();
                                        drNew["EMP_NO"] = "0";
                                        drNew["JOINING_YEAR"] = lastYear + 1;
                                        dt.Rows.InsertAt(drNew, i);
                                        i++;
                                        lastYear++;
                                    }
                                }
                            }
                        }
                        else if (rowYear == lastYear + 1)
                        {
                            lastYear = rowYear;
                        }
                        if (lastYear == 0)
                        {
                            lastYear = rowYear;
                        }
                        i++;
                    }
                    grdPosition.DataSource = dt;
                    grdPosition.DataBind();
                    grid_block.Visible = true;
                    grdPosition.Visible = true;

                    for (int r = 0; r < grdPosition.Rows.Count; r++)
                    {
                        Label lblemployeeNO = (Label)grdPosition.Rows[r].FindControl("lblEmpNo");
                        //   Label lblemployeeNO = (Label)e.Row.FindControl("lblEmpNo");
                        if (lblemployeeNO.Text.ToString().Equals("0"))
                        {
                            Label lblemployeeName = (Label)grdPosition.Rows[r].FindControl("lblcatjoinQuota");
                            //  Label lblemployeeName = (Label)e.Row.FindControl("lblcatjoinQuota");
                            // Label lblYear = (Label)e.Row.FindControl("lblYear");
                            Label lblYear = (Label)grdPosition.Rows[r].FindControl("lblYear");
                            lblemployeeName.Text = "NO RECRUITMENT IN THE YEAR " + lblYear.Text;
                            grdPosition.Rows[r].Cells[1].Attributes.Add("colspan", 7 + "");
                            for (int j = 2; j < grdPosition.Columns.Count; j++)
                            {
                                int val = grdPosition.Rows.Count;
                                grdPosition.Rows[r].Cells[j].Visible = false;
                            }
                        }
                    }
                }
                else
                {
                    grid_block.Visible = false;
                    grdPosition.Visible = false;
                }
            }
            catch (Exception ex)
            {
                string strerrormsg = ex.Message.Replace("'", "");
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is " + strerrormsg + "');location.replace('https://mygail.gail.co.in/');", true);
            }

        }

        protected void grdPosition_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {


                }
            }
            catch (Exception ex)
            {
                string strerrormsg = ex.Message.Replace("'", "");
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "done", "alert('The issue is " + strerrormsg + "');location.replace('https://mygail.gail.co.in/');", true);
            }
        }

        protected void grdcategorydescription_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView dr = (DataRowView)e.Row.DataItem;

                string Category = dr["JOINING_CATEGORY_QUOTA"].ToString().Trim();
                int Categorycount = Convert.ToInt32(dr["total"]);
                if (Category == "UR")
                {
                    Label lblREQUIRED = (Label)e.Row.FindControl("lblREQUIRED");
                    Label lblEXCESS = (Label)e.Row.FindControl("lblEXCESS");
                    lblREQUIRED.Text = ((Convert.ToInt32(ViewState["UR"]) * Convert.ToInt32(hidtotalcount.Value)) / 100).ToString();
                    lblEXCESS.Text = (Convert.ToDecimal(Categorycount) - Convert.ToDecimal(lblREQUIRED.Text)).ToString();
                    ViewState["lbl_UR_REQUIRED"] = lblREQUIRED.Text;
                    ViewState["lbl_UR_EXCESS"] = lblEXCESS.Text;
                }
                else if (Category == "OBC")
                {
                    Label lblREQUIRED = (Label)e.Row.FindControl("lblREQUIRED");
                    Label lblEXCESS = (Label)e.Row.FindControl("lblEXCESS");
                    lblREQUIRED.Text = ((Convert.ToInt32(ViewState["OBC"]) * Convert.ToInt32(hidtotalcount.Value)) / 100).ToString();
                    lblEXCESS.Text = (Convert.ToDecimal(Categorycount) - Convert.ToDecimal(lblREQUIRED.Text)).ToString();
                    ViewState["lbl_OBC_REQUIRED"] = lblREQUIRED.Text;
                    ViewState["lbl_OBC_EXCESS"] = lblEXCESS.Text;
                }
                else if (Category == "SC")
                {
                    Label lblREQUIRED = (Label)e.Row.FindControl("lblREQUIRED");
                    Label lblEXCESS = (Label)e.Row.FindControl("lblEXCESS");
                    lblREQUIRED.Text = ((Convert.ToInt32(ViewState["SC"]) * Convert.ToInt32(hidtotalcount.Value)) / 100).ToString();
                    lblEXCESS.Text = (Convert.ToDecimal(Categorycount) - Convert.ToDecimal(lblREQUIRED.Text)).ToString();
                    ViewState["lbl_SC_REQUIRED"] = lblREQUIRED.Text;
                    ViewState["lbl_SC_EXCESS"] = lblEXCESS.Text;
                }
                else if (Category == "ST")
                {
                    Label lblREQUIRED = (Label)e.Row.FindControl("lblREQUIRED");
                    Label lblEXCESS = (Label)e.Row.FindControl("lblEXCESS");
                    lblREQUIRED.Text = ((Convert.ToInt32(ViewState["ST"]) * Convert.ToInt32(hidtotalcount.Value)) / 100).ToString();
                    lblEXCESS.Text = (Convert.ToDecimal(Categorycount) - Convert.ToDecimal(lblREQUIRED.Text)).ToString();
                    ViewState["lbl_ST_REQUIRED"] = lblREQUIRED.Text;
                    ViewState["lbl_ST_EXCESS"] = lblEXCESS.Text;
                }
            }
        }




    }
}